# Seaography

If you are building a web API that perform selecting nested relation extensively. Consider serving a GraphQL server instead. [seaography](https://github.com/SeaQL/seaography) is a GraphQL framework for building GraphQL resolvers using SeaORM entities. With GraphQL resolver in place select above nested relation is straightforward and easy. Check "[Getting Started with Seaography](https://www.sea-ql.org/blog/2022-09-27-getting-started-with-seaography/#query-data-via-graphql)" to learn more.
