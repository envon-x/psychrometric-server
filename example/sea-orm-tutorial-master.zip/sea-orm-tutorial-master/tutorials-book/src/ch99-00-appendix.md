# Appendix

Thanks for reading the SeaORM tutorial from start to end! Glad you make it this far!!

We have a few more things for you, read on!
