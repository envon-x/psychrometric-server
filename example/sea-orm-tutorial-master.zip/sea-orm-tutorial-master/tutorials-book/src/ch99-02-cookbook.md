# Cookbook

The [SeaORM Cookbook](https://www.sea-ql.org/sea-orm-cookbook/) is a collection of frequently asked questions and the best practice of SeaORM.
