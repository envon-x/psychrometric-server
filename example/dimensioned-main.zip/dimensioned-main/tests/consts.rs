#![cfg(feature = "spec")]
#![feature(specialization)]

include!(concat!(env!("OUT_DIR"), "/test_consts.rs"));
