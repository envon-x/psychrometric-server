-- Add down migration script here
DROP TABLE products;

DROP TABLE users;
